package com.example.dataplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataplatformApplication {
    public static void main(String[] args) {
        SpringApplication.run(DataplatformApplication.class, args);
    }

}
