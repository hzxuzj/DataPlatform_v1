package com.example.dataplatform.controller;

import com.alibaba.fastjson.JSONObject;
import org.springframework.web.bind.annotation.*;

@RestController
public class SceneResultController {
    @RequestMapping(value="/dataplatform/result",method = RequestMethod.POST)
    public void getDepartmentbyid(@RequestBody JSONObject jsonParam){
        System.out.println(jsonParam.toJSONString());
    }
}
